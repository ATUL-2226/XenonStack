package com.bookStore.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Product {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String fname;
	private String fmob;
	private String faddress;
	private String pname;
	private double prate;
	private float pquantity;
	private String describ;
	private String image;
	
	
	public Product() {
		
	}

	public Product(int id) {
		super();
		this.id = id;
	}
		

public Product(String fname, String fmob, String faddress, String pname, double prate, float pquantity,
			String describ) {
		super();
		this.fname = fname;
		this.fmob = fmob;
		this.faddress = faddress;
		this.pname = pname;
		this.prate = prate;
		this.pquantity = pquantity;
		this.describ = describ;
	}

public Product(int id, String fname, String fmob, String faddress, String pname, double prate, float pquantity,
			String describ) {
		super();
		this.id = id;
		this.fname = fname;
		this.fmob = fmob;
		this.faddress = faddress;
		this.pname = pname;
		this.prate = prate;
		this.pquantity = pquantity;
		this.describ = describ;
		
	}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public String getFname() {
	return fname;
}

public void setFname(String fname) {
	this.fname = fname;
}

public String getFmob() {
	return fmob;
}

public void setFmob(String fmob) {
	this.fmob = fmob;
}

public String getFaddress() {
	return faddress;
}

public void setFaddress(String faddress) {
	this.faddress = faddress;
}

public String getPname() {
	return pname;
}

public void setPname(String pname) {
	this.pname = pname;
}

public double getPrate() {
	return prate;
}

public void setPrate(double prate) {
	this.prate = prate;
}

public float getPquantity() {
	return pquantity;
}

public void setPquantity(float pquantity) {
	this.pquantity = pquantity;
}

public String getDescrib() {
	return describ;
}

public void setDescrib(String describ) {
	this.describ = describ;
}

public String getImage() {
	return image;
}

public void setImage(String image) {
	this.image = image;
}

@Override
public String toString() {
	return "Product [id=" + id + ", fname=" + fname + ", fmob=" + fmob + ", faddress=" + faddress + ", pname=" + pname
			+ ", prate=" + prate + ", pquantity=" + pquantity + ", describ=" + describ + "]";
}



}