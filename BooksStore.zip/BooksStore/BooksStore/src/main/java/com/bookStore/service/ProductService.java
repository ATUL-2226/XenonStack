package com.bookStore.service;

import java.util.List;

import com.bookStore.model.Product;

public interface ProductService {
	void add(Product product);
	void modify(Product product);
	void removeById(int id);
	Product getById(int id);
	List<Product> getAll();
	
	
	void upload(int id,String image);
}
